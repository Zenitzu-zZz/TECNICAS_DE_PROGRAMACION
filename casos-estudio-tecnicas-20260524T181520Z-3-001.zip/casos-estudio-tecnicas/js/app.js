const selectEjemplo = document.getElementById('id-select-ejemplo')


let vectorEjemplo = []
const vector2Ejemplo = ['valor1', 'valor2',]

btnCargarEjemplo.addEventListener('click', function (e) {

})


function cargarVector(dimension) {
  for (let i = 0; i < dimension; i++) {
    // Generar un número aleatorio entre 10 y 5000
    const numEntero = Math.floor(Math.random() * (5000 - 10 + 1)) + 10;
    // Generar un número decimal aleatorio entre 10 y 5000 con dos decimales
    // const numDecimal2 = (Math.random() * (5000 - 10) + 10).toFixed(2)

    vectorEjemplo[i] = numEntero
    // vectorEjemplo[i] = numDecimal2
  }
}
